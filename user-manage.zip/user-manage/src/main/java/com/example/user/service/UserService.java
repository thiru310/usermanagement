package com.example.user.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.JdbcTemplateAutoConfiguration;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.user.dao.UserDao;

@Service
public class UserService {

	@Autowired
	JdbcTemplate jdbctemplate;
	
	/**
	 * @param userdao
	 * @return
	 * @throws DataIntegrityViolationException
	 * @throws RuntimeException
	 * @throws Exception
	 * 
	 * This Method is used for register where it will be called from RESTController to insert the values in the Database.
	 */
	public int createUser(UserDao userdao) throws DataIntegrityViolationException ,RuntimeException, Exception {
		int norowsupdated = 0;
		try {
			long time = System.currentTimeMillis();
			java.sql.Timestamp timestamp = new java.sql.Timestamp(time);
			String insertuserDetailsquery = "INSERT INTO USERTABLE(EMAIL,NAME,PASSWORD,USERCREATEDAT) values(?,?,?,?)";
			norowsupdated = jdbctemplate.update(insertuserDetailsquery,userdao.getEmail(), userdao.getName(), userdao.getPassword(),timestamp);
			
		}catch (DataIntegrityViolationException die) {
			norowsupdated = 101;
			System.out.println("User Already Exists with the same Email");
			throw new DataIntegrityViolationException("Trying to Insert Duplicate Entry in the Db",die);
	    }
		catch(RuntimeException re) {
			System.out.println("DataAccessException Occurred in createUser method");
			throw new RuntimeException("Runime/DataAccessException Occurred in createUser method",re);
		}
		catch(Exception e) {
			System.out.println("Exception occurred in createUser method");
			throw new Exception("Exception occurred in createUser method",e);
		}
		return norowsupdated;
		
	}
	
	/**
	 * @param email
	 * @param pass
	 * @return
	 * @throws RuntimeException
	 * @throws Exception
	 * 
	 * This method is used to check whether user already exists or not in the database
	 */
	public boolean checkUserExits(String email,String pass) throws RuntimeException, Exception {
		boolean userExists = false;
		try {
			String query = "SELECT EMAIL, PASSWORD FROM USERTABLE WHERE EMAIL=? AND PASSWORD=?"; 
	        Object[] inputs = new Object[] {email, pass};
	        List<UserDao> userdata = jdbctemplate.query(query, inputs, new RowMapper<UserDao>() {
	            public UserDao mapRow(ResultSet result, int rowNum) throws SQLException {
	            	UserDao userdao = new UserDao();
	            	userdao.setEmail(result.getString("email"));
	            	userdao.setPassword(result.getString("password"));
	                 
	                return userdao;
	            }
	             
	        });
	        if(userdata.size() > 0 && !userdata.isEmpty() && userdata != null) {
	        	userExists = true;
	        }
		}catch(RuntimeException re) {
			System.out.println("DataAccessException Occurred in checkUserExits method");
			re.printStackTrace();
			throw new RuntimeException("Runime/DataAccessException Occurred in checkUserExits method",re);
		}
		catch(Exception e) {
			System.out.println("Exception occurred in checkUserExits method");
			throw new Exception("Exception occurred in checkUserExits method",e);
		}
		return userExists;
	}
	
	/**
	 * @param email
	 * @return
	 * @throws RuntimeException
	 * @throws Exception
	 * 
	 * This method is used to update the loggedintime in database
	 */
	public UserDao updateloggedintime(String email) throws RuntimeException, Exception {
		UserDao userdao = null;
		try {
		long time = System.currentTimeMillis();
		java.sql.Timestamp timestamp = new java.sql.Timestamp(time);
		String updateuserDetailsquery = "UPDATE USERTABLE SET CURRENTLOGIN=? where EMAIL=?";
		int norowsupdated = jdbctemplate.update(updateuserDetailsquery,timestamp,email);
		String getuserDetailsQuery = "SELECT EMAIL,NAME,CURRENTLOGIN FROM USERTABLE WHERE EMAIL=?";
		Map<String, Object> map = null;
		if(norowsupdated > 0) {
			map = jdbctemplate.queryForMap(getuserDetailsQuery, email);
		}
		userdao = new UserDao();
		userdao.setEmail(String.valueOf(map.get("email")));
		userdao.setName(String.valueOf(map.get("name")));
		if(map.get("lastlogin") != null) {
			userdao.setLastLogin(Timestamp.valueOf(String.valueOf(map.get("lastlogin"))));
		}
		if(map.get("currentlogin") != null) {
			userdao.setCurrentLogin(Timestamp.valueOf(String.valueOf(map.get("currentlogin"))));
		}
		
		}catch(RuntimeException re) {
			System.out.println("DataAccessException Occurred in updateloggedintime method");
			re.printStackTrace();
			throw new RuntimeException("Runime/DataAccessException Occurred in updateloggedintime method",re);
		}
		catch(Exception e) {
			System.out.println("Exception occurred in updateloggedintime method");
			throw new Exception("Exception occurred in updateloggedintime method",e);
		}
		return userdao;
	}
	
	/**
	 * @param userdao
	 * @return
	 * @throws RuntimeException
	 * @throws Exception
	 * 
	 * This method is used to update the user details, for example user can change his name and the password
	 */
	public int updateUser(UserDao userdao) throws RuntimeException, Exception {
		System.out.println("Update User Method >>");
		int norowsupdated =0;
		try {
		String updateuserDetailsquery = "UPDATE USERTABLE SET NAME=?, PASSWORD=? where EMAIL=?";
		norowsupdated = jdbctemplate.update(updateuserDetailsquery, userdao.getName(), userdao.getPassword(),userdao.getEmail());
		}catch(RuntimeException re) {
			System.out.println("DataAccessException Occurred in updateUser method");
			throw new RuntimeException("Runime/DataAccessException Occurred in updateUser method",re);
		}
		catch(Exception e) {
			System.out.println("Exception occurred in updateUser method");
			throw new Exception("Exception occurred in updateUser method",e);
		}
		return norowsupdated;
	}
	
	/**
	 * @param email
	 * @return
	 * @throws RuntimeException
	 * @throws Exception
	 * 
	 * This method is used to update the last login column in the database when the user clicks on  log out
	 */
	public int updatelastlogintime(String email) throws RuntimeException, Exception {
		System.out.println("Update User Method >>");
		int norowsupdated = 0;
		try {
		String getCurrentlogintimequery = "SELECT CURRENTLOGIN FROM USERTABLE WHERE EMAIL=?";
		Map<String, Object> map = null;
		map = jdbctemplate.queryForMap(getCurrentlogintimequery, email);
		String updatelastlogintime = "UPDATE USERTABLE SET LASTLOGIN=? where EMAIL=?";
		norowsupdated = jdbctemplate.update(updatelastlogintime, Timestamp.valueOf(String.valueOf(map.get("CURRENTLOGIN"))), email);
		}catch(RuntimeException re) {
			System.out.println("DataAccessException Occurred in updatelastlogintime method");
			throw new RuntimeException("Runime/DataAccessException Occurred in updatelastlogintime method",re);
		}
		catch(Exception e) {
			System.out.println("Exception occurred in updatelastlogintime method");
			throw new Exception("Exception occurred in updatelastlogintime method",e);
		}
		return norowsupdated;
	}
	
	/**
	 * @param email
	 * @throws RuntimeException
	 * @throws Exception
	 * 
	 * This method is called from RESTController and it is used to delete the user entry in the database
	 */
	public void deleteUser(String email) throws RuntimeException, Exception {
		try {
		
		String deleteuserquery = "DELETE FROM USERTABLE WHERE EMAIL=?";
		jdbctemplate.update(deleteuserquery,email);
		}catch(RuntimeException re) {
			System.out.println("DataAccessException Occurred in GetUserDetail method");
			throw new RuntimeException("Runime/DataAccessException Occurred in GetUserDetail method",re);
		}
		catch(Exception e) {
			System.out.println("Exception occurred in GetUserDetail method");
			throw new Exception("Exception occurred in GetUserDetail method",e);
		}
	}
	
	/**
	 * @param email
	 * @return
	 * @throws RuntimeException
	 * @throws Exception
	 * 
	 * This method is called from RESTController and it is used to fetch the user details based on the email paramater
	 */
	public UserDao getUserDetail(String email) throws RuntimeException,Exception {
		final UserDao userdao = new UserDao();
		try {
			System.out.println("Get User Details Method >> "+email);
			String getUserDetailquery = "SELECT EMAIL, NAME, CURRENTLOGIN, LASTLOGIN,USERCREATEDAT from USERTABLE where EMAIL = ?";
			Map<String, Object> map = null;
			
			map =  jdbctemplate.queryForMap(getUserDetailquery,email);
			userdao.setEmail(String.valueOf(map.get("email")));
			userdao.setName(String.valueOf(map.get("name")));
			if(map.get("lastlogin") != null) {
				userdao.setLastLogin(Timestamp.valueOf(String.valueOf(map.get("lastlogin"))));
			}
			if(map.get("currentlogin") != null) {
				userdao.setCurrentLogin(Timestamp.valueOf(String.valueOf(map.get("currentlogin"))));
			}
			if(map.get("usercreatedat") != null) {
				userdao.setCreatedAt(Timestamp.valueOf(String.valueOf(map.get("usercreatedat"))));
			}
		}catch(RuntimeException re) {
			System.out.println("DataAccessException Occurred in GetUserDetail method");
			throw new RuntimeException("DataAccessException Occurred in GetUserDetail method",re);
		}
		catch(Exception e) {
			System.out.println("Exception occurred in GetUserDetail method");
			throw new Exception("Exception occurred in GetUserDetail method",e);
		}
		
		return userdao;
	}
	
	
	/**
	 * @return List<UserDao>
	 * @throws RuntimeException
	 * @throws Exception
	 * 
	 * This method is called from RESTController to fetch all the registered users
	 */
	public List<UserDao>  getAllUsers() throws RuntimeException , Exception {
		List<UserDao> userdaolist = new ArrayList<UserDao>();
		try {
		String getalluser = "SELECT NAME, EMAIL, LASTLOGIN,USERCREATEDAT FROM USERTABLE";
		List<Map<String, Object>> list = jdbctemplate.queryForList(getalluser);
		for (Map<String, Object> row : list) {
			UserDao userdao = new UserDao();			
			userdao.setEmail(String.valueOf(row.get("email")));
			userdao.setName(String.valueOf(row.get("name")));
			userdao.setCreatedAt(Timestamp.valueOf(String.valueOf(row.get("usercreatedat"))));
			if(row.get("lastlogin") != null) {
				userdao.setLastLogin(Timestamp.valueOf(String.valueOf(row.get("lastlogin"))));
			}
			
			userdaolist.add(userdao);
	    } 
		
			System.out.println(Arrays.toString(userdaolist.toArray()));
		}catch(RuntimeException re) {
			System.out.println("DataAccessException Occurred in GetUserDetail method");
			throw new RuntimeException("DataAccessException Occurred in getAllUsers()",re);
		}
		catch(Exception e) {
			System.out.println("Exception occurred in getAllUsers method");
			throw new Exception("Exception occurred in getAllUsers method",e);
		}
        return userdaolist;
	}
}
