package com.example.user.dao;

import java.sql.Timestamp;

public class UserDao {
	
	private String email;
	private String name;
	private String password;
	private Timestamp lastLogin;
	private Timestamp currentLogin;
	private Timestamp createdAt;
	private String errormsg;
	private String successmsg;
	
	public UserDao() {
		super();
		// TODO Auto-generated constructor stub
	}

	


	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}




	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}




	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}




	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}




	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}




	/**
	 * @param password the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}




	/**
	 * @return the lastLogin
	 */
	public Timestamp getLastLogin() {
		return lastLogin;
	}




	/**
	 * @param lastLogin the lastLogin to set
	 */
	public void setLastLogin(Timestamp lastLogin) {
		this.lastLogin = lastLogin;
	}




	/**
	 * @return the currentLogin
	 */
	public Timestamp getCurrentLogin() {
		return currentLogin;
	}




	/**
	 * @param currentLogin the currentLogin to set
	 */
	public void setCurrentLogin(Timestamp currentLogin) {
		this.currentLogin = currentLogin;
	}




	/**
	 * @return the createdAt
	 */
	public Timestamp getCreatedAt() {
		return createdAt;
	}




	/**
	 * @param createdAt the createdAt to set
	 */
	public void setCreatedAt(Timestamp createdAt) {
		this.createdAt = createdAt;
	}




	/**
	 * @return the errormsg
	 */
	public String getErrormsg() {
		return errormsg;
	}




	/**
	 * @param errormsg the errormsg to set
	 */
	public void setErrormsg(String errormsg) {
		this.errormsg = errormsg;
	}




	/**
	 * @return the successmsg
	 */
	public String getSuccessmsg() {
		return successmsg;
	}




	/**
	 * @param successmsg the successmsg to set
	 */
	public void setSuccessmsg(String successmsg) {
		this.successmsg = successmsg;
	}




	@Override
	public String toString() {
		return "UserDao [email=" + email + ", name=" + name + ", password=" + password + ", lastLogin=" + lastLogin
				+ ", currentLogin=" + currentLogin + ", createdAt=" + createdAt + ", errormsg=" + errormsg
				+ ", successmsg=" + successmsg + "]";
	}


	
	
	
	

}
