package com.example.user.controller;


import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.example.user.dao.UserDao;
import com.example.user.service.UserService;


@RestController
public class UserMangeControl {
	
	private final Logger log = LogManager.getLogger(this.getClass());

	@Autowired
	UserService userserice;
	
	/**
	 * @param model
	 * @param session
	 * @return
	 * 
	 * This request mapping is used for redirecting to login page
	 */
	@RequestMapping(value="/",method=RequestMethod.GET)
	public ModelAndView showloginPage(ModelMap model,HttpSession session) {
		ModelAndView mv = new ModelAndView();
		try {
		if(session.getAttribute("username") != null) {
			String email = String.valueOf(session.getAttribute("username"));
			userserice.updatelastlogintime(email);
			session.removeAttribute("username");
		}
		mv.setViewName("loginpage");
		}catch(Exception e) {
			System.out.println("Excepetion Occurred while login page redirection");
		}
		return mv;
	}
	
	/**
	 * @param model
	 * @param session
	 * @return
	 * 
	 * This request mapping is used for redirecting to login page
	 */
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public ModelAndView loginpageredirection(ModelMap model,HttpSession session) {
		ModelAndView mv = new ModelAndView();
		try {
		if(session.getAttribute("username") != null) {
			String email = String.valueOf(session.getAttribute("username"));
			userserice.updatelastlogintime(email);
			session.removeAttribute("username");
		}
		mv.setViewName("loginpage");
		}catch(Exception e) {
			System.out.println("Excepetion Occurred while login page redirection");
		}
		return mv;
	}
	
	/**
	 * @param model
	 * @return
	 * 
	 * This request mapping is used for redirecting to home page of the application
	 */
	@RequestMapping(value="/secure/welcome",method=RequestMethod.GET)
	public ModelAndView showwelcomePage(ModelMap model) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("welcome");
		return mv;
	}
	
	/**
	 * @param model
	 * @param session
	 * @param email
	 * @return
	 * 
	 * This request mapping is used for redirecting to update details form page
	 */
	@RequestMapping(value="/secure/updateDetails",method=RequestMethod.GET)
	public ModelAndView showUpdateDetailsPage(ModelMap model, HttpSession session, @RequestParam String email) {
		System.out.println("Value in the session is >> "+String.valueOf(session .getAttribute("username")));
		ModelAndView mv = new ModelAndView();
		mv.addObject("email", email);
		mv.setViewName("UpdateDetailsPage");
		return mv;
	}
	
	/**
	 * @return
	 * 
	 * This request mapping is used for redirecting to registration page
	 */
	@RequestMapping(value="/registerform",method=RequestMethod.GET)
	public ModelAndView showRegisterPage() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("register");
		return mv;
	}
	
	/**
	 * @param model
	 * @param payload
	 * @param session
	 * @return
	 * @throws JSONException
	 * 
	 * This request mapping method is used for after login
	 */
	@RequestMapping(value="/logedin",method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<UserDao> userlogin(ModelMap model,@RequestBody String payload, HttpSession session) throws JSONException {
		System.out.println("Payload in UserLogin >> "+payload);
		UserDao userdao = null;
		try {
		JSONObject jsonObj = new JSONObject(payload);
		String email = String.valueOf(jsonObj.get("email"));
		String password = String.valueOf(jsonObj.get("password"));
		boolean userExists = userserice.checkUserExits(email,password);
		
		if(userExists) {
			userdao = userserice.updateloggedintime(email);
			session.setAttribute("username", email);
			session.setMaxInactiveInterval(3600);
			userdao.setSuccessmsg("User Signed In");
		}else {
			userdao = new UserDao();
			System.out.println("Invalid Credentials or You have not registed Yet.");
			model.put("loginerrmsg", "Invalid Credentials or You have not registed Yet.");
			userdao.setErrormsg("Invalid Credentials. Please Try again..");
		}
		}
		catch (Exception e) {
			System.out.println("Excetion Occurred in userlogin method");
		}
		return new ResponseEntity<UserDao>(userdao, HttpStatus.OK);
	}
	
	/**
	 * @param model
	 * @param payload
	 * @return
	 * @throws JSONException
	 * 
	 * This request mapping method is used for user registration where it will get all the values and store it in the database
	 */
	@RequestMapping(value="/register",method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<UserDao> registerUser(ModelMap model,@RequestBody String payload) throws JSONException {
		UserDao userdao = null;
		try {
		JSONObject jsonObj = new JSONObject(payload);
		userdao = new UserDao();
		userdao.setEmail(String.valueOf(jsonObj.get("email")));
		userdao.setName(String.valueOf(jsonObj.get("name")));
		userdao.setPassword(String.valueOf(jsonObj.get("password")));
		int count = userserice.createUser(userdao);
		System.out.println("Value of the count  >>"+count);
		if(count == 101) {
			userdao.setErrormsg("Error Code 101 : User Already registered with this Email.");
		}else if(count != 101) {
			userdao.setSuccessmsg("Response Code 2001 :  User Created Successfully");
		}
		}catch(Exception e) {
			System.out.println("Exception Occurred in registerUser Method");
		}
		return new ResponseEntity<UserDao>(userdao, HttpStatus.OK);
	}
	
	/**
	 * @param session
	 * @return
	 * 
	 * This request mapping method is used to make the used logout from the application
	 */
	@RequestMapping(value = "/secure/logout", method = RequestMethod.POST)
	public ModelAndView logout(HttpSession session) {
		try {
		String email = String.valueOf(session.getAttribute("username"));
		userserice.updatelastlogintime(email);
		session.removeAttribute("username");
		}catch(Exception e) {
			System.out.println("Exception occurred in logout method");
		}
		return new ModelAndView("loginpage");
	}
	
	/**
	 * @param session
	 * @param email
	 * @return
	 * 
	 * This request mapping method is used to unsubscribe the user from the application which means the user details will be deleted from database
	 * and logged out from the application
	 */
	@RequestMapping(value = "/secure/unsubscribe", method = RequestMethod.GET)
	public ModelAndView unsubscribeAndLogout(HttpSession session, @RequestParam String email) {
		try {
		String sessionemail = String.valueOf(session.getAttribute("username"));
		if(sessionemail != null && sessionemail.equals(email)) {
			userserice.deleteUser(sessionemail);
			session.removeAttribute("username");
		}
		
		}catch(Exception e) {
			System.out.println("Exception occurred in logout method");
		}
		return new ModelAndView("loginpage");
	}
	
	/**
	 * @param payload
	 * @param session
	 * @return
	 * @throws JSONException
	 * 
	 * This request mapping is used to update the user details
	 */
	@RequestMapping(value="/secure/updateuser", method=RequestMethod.POST, consumes="application/json", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<UserDao> updateUserDetails(@RequestBody String payload, HttpSession session) throws JSONException {
		System.out.println("Payload >>>>"+payload);
		UserDao userdao = null;
		try {
		String email = String.valueOf(session.getAttribute("username"));
		System.out.println("Email >> "+email);
		JSONObject jsonObj = new JSONObject(payload);
		userdao = new UserDao();
		userdao.setEmail(String.valueOf(jsonObj.get("email")));
		userdao.setName(String.valueOf(jsonObj.get("name")));
		userdao.setPassword(String.valueOf(jsonObj.get("password")));
		int count = userserice.updateUser(userdao);
		System.out.println("Couunt >>>"+count);
		if(count > 0) {
			userdao.setSuccessmsg("Your Details Updated Successfully");
		}
		}catch(Exception e) {
			System.out.println("Exception occurred in UpdateUser method");
		}
		return new ResponseEntity<UserDao>(userdao, HttpStatus.OK);
		
	}
	
	/**
	 * @param model
	 * @param session
	 * @param email
	 * @return ModelAndView
	 * 
	 * This request mapping is used to fetch the loggedin users details
	 */
	@RequestMapping(value="/secure/getUserDetails", method=RequestMethod.GET)
	public ModelAndView getUserDetails(ModelMap model, HttpSession session, @RequestParam String email) {
		String emailfrom = String.valueOf(session.getAttribute("username"));
		ModelAndView modelandview = new ModelAndView();
		UserDao userdao;
		try {
		if(email.equalsIgnoreCase(emailfrom)) {
			userdao = userserice.getUserDetail(email);
			modelandview.addObject("userdao", userdao);
			modelandview.setViewName("welcome");
			} 
		}catch (Exception e) {
			System.out.println("Exception Occurred in getUserDetails");
				e.printStackTrace();
			}
		
		
		return modelandview;
	}
	
	/**
	 * @return List<UserDao>
	 * 
	 * This method is been written for testing request mapping from browser
	 */
	
	@RequestMapping(value="/allUserDetails", method=RequestMethod.GET)
	public List<UserDao> allUserDetails() {
		List<UserDao> userdao = null;
		try {
			userdao = userserice.getAllUsers();
		}catch(Exception e) {
			System.out.println("Exception Occurred in getallUserDetails");
		}
		return userdao;
	}
	
	
	/**
	 * @param model
	 * @param session
	 * @param email
	 * @return ModelAndView
	 * 
	 * This RequestMaping is used to fetch all the uses who have registered on this application
	 */
	@RequestMapping(value="/getAllUserDetails", method=RequestMethod.GET)
	public ModelAndView getallUserDetails(ModelMap model, HttpSession session, @RequestParam String email) {
		List<UserDao> userdao = null;
		ModelAndView modelandview = new ModelAndView();
		try {
			userdao = userserice.getAllUsers();
			modelandview.addObject("userdao", userdao);
			modelandview.addObject("email", email);
			modelandview.setViewName("showusers");
		}catch(Exception e) {
			System.out.println("Exception Occurred in getallUserDetails");
		}
		return modelandview;
	}
	
	
}
